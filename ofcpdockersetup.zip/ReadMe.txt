What are these files/folders?
- "CreateCustomDockerImage.ps1" the powershell script to run to create your custom OCP image
- "DockerfileCustomOcp" docker file to create the custom image; shouldn't really be changed
- "plugins" this folder is empty by default; if you need to add custom DLLs to your image put them here and they will be added to the image
- "appsettings.Production.json" this will override the "appsettings.Production.json" file in your image

How to customize your image?
- add custom files inside the "plugins" folder
- update the json file "appsettings.Production.json"; in this example is a Disconnected configuration
- run the powershell script

How to run?
Open a powershell inside this folder path and execute the script `.\CreateCustomDockerImage.ps1`
On success you should have a docker image called "ocpcustom"

How to deploy?
The OCP image is a standard docker image so it can be deploy Kubernetes or any other similar tool.

Note:
Sensitive data like the JWT Secret Key and the Vault's secrets should not be kept in the appsettings.Production.json file or anywhere inside the Docker image.
Instead you should use `Kubernetes Secrets` and pass those secrets to the enviroment at runtime.
https://kubernetes.io/docs/concepts/configuration/secret/
To calculate the appsettings parameter name for the enviroment variable you need to
- take the JSON path of the parameter from the appsettings.production.json
- replace hierarchy delimiters ":"/"." with "__" in the path
https://learn.microsoft.com/en-us/aspnet/core/fundamentals/configuration/?view=aspnetcore-8.0#non-prefixed-environment-variables

Exmaples
1. SecureStores: in the appsettings file it's `appSettings__Plugins.SecureStores` so the env var name shoudl be `appSettings__Plugins.SecureStores`
2. JWT Keys (array): in the appsettings file it's `Jwt:Keys[0]` then the env var names should be `Jwt__Keys__0`
3. Disconnected Configuration Parameter: in the appsettings file it's `AppSettings:SecureStoreConfigurations[0]:Context:APIRegistrationKey` then the env var names should be `AppSettings__SecureStoreConfigurations__0__Context__APIRegistrationKey`

For the provided appSettings.Production.json file you would need the following env variables
- Jwt__Keys__0="secret key"
- AppSettings__SecureStoreConfigurations__0__Context__APIRegistrationKey="apiKey"
- AppSettings__SecureStoreConfigurations__0__Context__Hostname="hostname"