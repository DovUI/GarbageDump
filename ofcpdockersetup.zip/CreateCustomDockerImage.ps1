param(

    [Parameter(Mandatory = $true)]
    [ValidatePattern("^\d+\.\d+\.\d+$")]
    [string]$OcpVersion = (Read-Host "Please enter a value for OcpVersion in the format X.Y.Z; For example 2.1.1")

)

Write-Host "You have entered the following:"
Write-Host "OcpVersion: $OcpVersion"

$cmd = "docker build -f DockerfileCustomOcp . -t ocpcustom --build-arg OcpVersion=$OcpVersion"
Invoke-Expression $cmd
